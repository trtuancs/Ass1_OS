#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int empty(struct queue_t * q) {
	return (q->size == 0);
}

void enqueue(struct queue_t * q, struct pcb_t * proc) {
	if (q->size == MAX_QUEUE_SIZE) return;
	q->proc[q->size] = proc;
	q->size = q->size + 1;
}

struct pcb_t * dequeue(struct queue_t * q) {
	if (q->size == 0) return NULL;

	int highest = 0;
	for (int i = 0; i < q->size; i++) {
		if (q->proc[i]->priority < q->proc[highest]->priority) {
			highest = i;
		}
	}
	//swap highest and last
	struct pcb_t * temp = q->proc[highest];
	q->proc[highest] = q->proc[q->size - 1];
	q->proc[q->size - 1] = temp;

	//delete highest by decreasing queue size by 1
	q->size = q->size - 1;

	//return highest
	return q->proc[q->size];
}

